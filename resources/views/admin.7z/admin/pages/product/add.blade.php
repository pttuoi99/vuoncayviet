@extends('admin.layouts.master')

@section('title')
	Thêm Sản Phẩm
@endsection

@section('content')
<div class="card shadow mb-4">
	<div class="card-header py-3">
		<h6 class="m-0 font-weight-bold text-primary">Thêm Sản Phẩm</h6>
	</div>
	<div class="row" style="margin: 10px">
		<div class="col-lg-6">
			<form role="form" action="{{route('product.store')}}" method="POST" enctype="multipart/form-data">
				@csrf
				<fieldset class="form-group">
					<label>Tên Sản Phẩm</label>
					<input class="form-control" name="name" placeholder="Nhập tên loại sản phẩm">
					@if($errors->has('name'))
						<div class="alert alert-danger">{{$errors->first('name')}}</div>
					@endif
				</fieldset>
				<div class="form-group">
					<label for="quantity">Số lượng</label>
					<input type="number" name="quantity" min="1" value="1" class="form-control">
				</div>
				<div class="form-group">
					<label for="price">Đơn giá</label>
					<input type="text" name="price" placeholder="Nhập đơn giá sản phẩm" class="form-control">
				</div>
				<div class="form-group">
					<label for="promotional">Giá khuyến mại</label>
					<input type="text" name="promotional" value="0" placeholder="Nhập giá khuyến mại nếu có" class="form-control">
				</div>
				<div class="form-group">
					<label for="image">Ảnh minh họa</label>
					<input type="file" name="image" class="form-control">
				</div>
				<div class="form-group">
					<label>Mô tả</label>
					<textarea name="description" id="demo" cols="5" rows="5" class="form-control"></textarea>
				</div>
				<div class="form-group">
					<label>Danh Mục Sản Phẩm</label>
					<select class="form-control" name="idCategory">
						@foreach($category as $cate)
							<option value="{{$cate->id}}">{{$cate->name}}</option>
						@endforeach
					</select>
				</div>
				<div class="form-group">
					<label>Loại Sản Phẩm</label>
					<select class="form-control" name="idProductType">
						@foreach($product_type as $pro)
							<option value="{{$cate->id}}">{{$pro->name}}</option>
						@endforeach
					</select>
				</div>
				<div class="form-group">
					<label>Status</label>
					<select class="form-control" name="status">
						<option value="1">Hiển thị</option>
						<option value="0">Không hiển thị</option>
					</select>
				</div>
				<button type="submit" class="btn btn-success">Thêm</button>
				<button type="reset" class="btn btn-primary">Nhập Lại</button>
			</form>
		</div>
	</div>
</div>
@endsection